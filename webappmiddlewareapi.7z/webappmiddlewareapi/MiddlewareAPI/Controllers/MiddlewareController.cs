using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using Azure.Identity;
using Azure.Security.KeyVault.Certificates;

[ApiController]
[Route("api/[controller]")]
public class MiddlewareController : ControllerBase
{
    private readonly IHttpClientFactory _httpClientFactory;

    public MiddlewareController(IHttpClientFactory httpClientFactory)
    {
        _httpClientFactory = httpClientFactory;
    }

    private static X509Certificate2 LoadClientCertificate()
    {
        string keyVaultUrl = "https://sjkeyvaultdemo.vault.azure.net/";
        string certificateName = "sjcertificate";

        // Authenticate with DefaultAzureCredential (adjust if needed)
        var credential = new DefaultAzureCredential();

        // Create a CertificateClient to access the Key Vault
        var certificateClient = new CertificateClient(new Uri(keyVaultUrl), credential);

        // Retrieve the certificate with policy
        var certificateWithPolicy = certificateClient.GetCertificate(certificateName);

        // Extract the secret associated with the certificate
        var secretClient = new Azure.Security.KeyVault.Secrets.SecretClient(new Uri(keyVaultUrl), credential);
        var secret = secretClient.GetSecret(certificateName);

        // Decode the PFX
        byte[] pfxBytes = Convert.FromBase64String(secret.Value.Value);

        // Load the certificate
        var certificate = new X509Certificate2(pfxBytes, (string)null, X509KeyStorageFlags.MachineKeySet);

        // Use the certificate (example: print details)
        Console.WriteLine($"Subject: {certificate.Subject}");
        Console.WriteLine($"Issuer: {certificate.Issuer}");
        Console.WriteLine($"Thumbprint: {certificate.Thumbprint}");

        return certificate;        
    }

    [HttpGet]
    [HttpPost]
    public async Task<IActionResult> CallAzureFunction()
    {
        try
        {
            string azureFunctionUrl = "https://sjfunctionappdmat.azurewebsites.net/api/CalcSum?param1=10&param2=33&code=lrpvtYGFkhOnh8duO31s7Wpl2PLP1reNUgj7H1f8hl0MAzFuAAf7Sg%3D%3D";
            
             // Load the client certificate (from file, store, or Azure Key Vault)
            X509Certificate2 clientCertificate = LoadClientCertificate();

            // Create HttpClient with the certificate
            var handler = new HttpClientHandler();
            handler.ClientCertificates.Add(clientCertificate);

            var client = new HttpClient(handler);

            // Call the Azure Function API
            var response = await client.GetAsync(azureFunctionUrl);

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return Ok(new { message = "Azure Function call successful: " + content });
            }
            else
            {
                return StatusCode((int)response.StatusCode, "Azure Function call failed.");
            }
            //return Ok(new {message = "middleware api called"});
        }
        catch (Exception ex)
        {
            return StatusCode(500, "Error: " + ex.Message);
        }
    }
}
